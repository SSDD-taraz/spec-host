<?php get_header(); ?>

<section class="page">
  <?php echo do_shortcode('[spec_module_head module="static_ip" fallback_title="STATIC IP" fallback_desc="Выделенные IP адреса для VDS, VPN, доступов и проектов." btn1_text="ORDER IP" btn1_url="#" btn2_text="ADMIN: MANAGE POOL" btn2_url="#"]'); ?>

  <?php echo do_shortcode('[spec_module_blocks module="static_ip" keys="features,security,deploy,admin" layout="grid2"]'); ?>
</section>

<section class="page">
  <h2 style="margin:0 0 14px 0">Тарифы Static IP</h2>
  <?php echo do_shortcode('[spec_tariffs type="static-ip" limit="12"]'); ?>
</section>

<?php get_footer(); ?>
