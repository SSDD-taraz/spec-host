
(function(){
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));

  const prefs = {
    boot: localStorage.getItem("sh_boot") !== "0",
    sound: localStorage.getItem("sh_sound") === "1",
    logs: localStorage.getItem("sh_logs") !== "0",
    admin: localStorage.getItem("sh_admin") === "1",
  };

  function beep(){
    if(!prefs.sound) return;
    try{
      const a = new Audio("assets/audio/beep.wav");
      a.volume = 0.35;
      a.play();
    }catch(e){}
  }

  function logEvent(level, message){
    const logBody = $("#logBody");
    if(!logBody) return;
    const ts = new Date().toTimeString().slice(0,8);
    const div = document.createElement("div");
    const cls = level === "OK" ? "ok" : (level === "WARN" ? "warn" : (level === "ERR" ? "err" : ""));
    div.className = `line ${cls}`;
    div.textContent = `${ts} [${level}] ${message}`;
    logBody.prepend(div);
    while(logBody.children.length > 60) logBody.removeChild(logBody.lastChild);
  }

  function setAdmin(on){
    prefs.admin = !!on;
    localStorage.setItem("sh_admin", prefs.admin ? "1" : "0");
    document.body.classList.toggle("admin", prefs.admin);
    logEvent("OK", prefs.admin ? "ADMIN MODE ENABLED" : "ADMIN MODE DISABLED");
    beep();
  }
  document.body.classList.toggle("admin", prefs.admin);

  // settings toggles
  const soundToggle = $("#toggleSound");
  const bootToggle  = $("#toggleBoot");
  const logsToggle  = $("#toggleLogs");
  const lp = $("#logPanel");

  if(soundToggle){
    soundToggle.checked = prefs.sound;
    soundToggle.addEventListener("change", () => {
      prefs.sound = soundToggle.checked;
      localStorage.setItem("sh_sound", prefs.sound ? "1" : "0");
      beep();
    });
  }
  if(bootToggle){
    bootToggle.checked = prefs.boot;
    bootToggle.addEventListener("change", () => {
      prefs.boot = bootToggle.checked;
      localStorage.setItem("sh_boot", prefs.boot ? "1" : "0");
      logEvent("OK", prefs.boot ? "BOOT ENABLED" : "BOOT DISABLED");
      beep();
    });
  }
  if(logsToggle){
    logsToggle.checked = prefs.logs;
    logsToggle.addEventListener("change", () => {
      prefs.logs = logsToggle.checked;
      localStorage.setItem("sh_logs", prefs.logs ? "1" : "0");
      if(lp) lp.style.display = prefs.logs ? "" : "none";
      beep();
    });
  }
  if(lp && !prefs.logs) lp.style.display = "none";

  // init logs
  ["Telemetry stream connected","Firewall rules loaded","WireGuard running","Routes stable"].forEach(m=>logEvent("OK", m));

  // BOOT overlay
  const boot = $("#boot");
  const bootLog = $("#bootLog");
  const bootEnter = $("#bootEnter");
  const bootLines = [
    {t:"[BOOT] Spec-Host Core v3.1", c:""},
    {t:"[OK] Power grid stabilized", c:"ok"},
    {t:"[OK] Firewall online", c:"ok"},
    {t:"[OK] NAT engine loaded", c:"ok"},
    {t:"[OK] WireGuard tunnels ready", c:"ok"},
    {t:"[OK] Nodes synced", c:"ok"},
    {t:"[OK] Telemetry stream connected", c:"ok"},
    {t:"[READY] Enter Control Room", c:"ok"},
  ];

  function showBoot(){
    if(!boot || !prefs.boot) return;
    document.body.classList.add("booting");
    boot.classList.add("on");
    if(bootLog) bootLog.innerHTML = "";
    let i=0;
    if(bootEnter) bootEnter.disabled = true;
    const step = () => {
      if(!bootLog) return;
      if(i < bootLines.length){
        const line = bootLines[i++];
        const div = document.createElement("div");
        div.className = line.c;
        div.textContent = line.t;
        bootLog.appendChild(div);
        bootLog.scrollTop = bootLog.scrollHeight;
        if(prefs.sound) beep();
        setTimeout(step, 340 + Math.random()*220);
      } else {
        if(bootEnter) bootEnter.disabled = false;
      }
    };
    setTimeout(step, 200);
  }
  function hideBoot(){
    if(!boot) return;
    boot.classList.remove("on");
    document.body.classList.remove("booting");
    beep();
  }
  if(bootEnter) bootEnter.addEventListener("click", hideBoot);

  if(sessionStorage.getItem("sh_boot_seen") !== "1"){
    showBoot();
    sessionStorage.setItem("sh_boot_seen","1");
  }

  // metrics + alert
  const latencyEl = $("#latency");
  const nodesEl   = $("#nodes");
  const uptimeEl  = $("#uptime");
  let nodesBase = 128;
  let alert = false;

  function setAlert(on, reason){
    document.body.classList.toggle("alert-mode", !!on);
    const banner = $("#alertBanner");
    if(banner){
      banner.innerHTML = on ? `ALERT MODE: <b>${reason || "DEGRADED"}</b> / CHECK NODES & ROUTES` : "";
    }
    alert = !!on;
  }

  if(latencyEl){
    setInterval(() => {
      const base = 12;
      const jitter = Math.floor(Math.random()*6)-2;
      const spike = (Math.random() < 0.06) ? Math.floor(Math.random()*18)+10 : 0;
      const v = base + jitter + spike;
      latencyEl.textContent = `${v} MS`;
      if(v >= 28 && !alert){
        setAlert(true, `LATENCY ${v}ms`);
        logEvent("WARN", `Latency spike detected: ${v}ms`);
        beep();
        setTimeout(()=> setAlert(false), 6000);
      }
    }, 1200);
  }
  if(nodesEl){
    setInterval(() => {
      const drift = (Math.random() < 0.20) ? (Math.random() < 0.5 ? -1 : 1) : 0;
      nodesBase = Math.max(80, Math.min(256, nodesBase + drift));
      nodesEl.textContent = `${nodesBase} ACTIVE`;
    }, 5200);
  }
  if(uptimeEl){
    let base = 99.99;
    setInterval(() => {
      const delta = (Math.random() < 0.7) ? 0 : (Math.random() < 0.5 ? -0.01 : 0.01);
      const v = Math.min(99.99, Math.max(99.90, base + delta));
      uptimeEl.textContent = v.toFixed(2) + "%";
    }, 14000);
  }

  const events = [
    ["OK","Route check passed"],
    ["OK","Node sync OK"],
    ["WARN","Edge node jitter +2ms"],
    ["OK","NAT table stable"],
    ["OK","DNS node reachable"],
    ["WARN","Peer handshake delayed (recovered)"],
  ];
  setInterval(() => {
    const [l,m] = events[Math.floor(Math.random()*events.length)];
    logEvent(l,m);
    if(l === "WARN" && Math.random() < 0.35) beep();
  }, 9000);

  // Node map
  const canvas = $("#nodeMap");
  const tip = $("#mapTip");
  const nodes = [
    {id:"MASTER", name:"Master Node", ip:"37.140.xxx.xxx", role:"CORE", status:"online", x:0, y:0, lat:12},
    {id:"EDGE-01", name:"Edge Node 01", ip:"185.28.xxx.xxx", role:"KZ", status:"online", x:0, y:0, lat:12},
    {id:"EDGE-02", name:"Edge Node 02", ip:"148.253.xxx.xxx", role:"EU", status:"online", x:0, y:0, lat:18},
    {id:"EDGE-03", name:"Edge Node 03", ip:"37.140.243.28", role:"VDS-0", status:"maint", x:0, y:0, lat:26},
    {id:"EDGE-04", name:"Edge Node 04", ip:"185.28.85.140", role:"DNS", status:"online", x:0, y:0, lat:11},
  ];

  function layoutNodes(w,h){
    const cx = w*0.5, cy = h*0.52;
    nodes[0].x = cx; nodes[0].y = cy;
    const r = Math.min(w,h)*0.32;
    const angle0 = -Math.PI/2;
    for(let i=1;i<nodes.length;i++){
      const a = angle0 + (i-1)*(Math.PI*2/(nodes.length-1));
      nodes[i].x = cx + Math.cos(a)*r;
      nodes[i].y = cy + Math.sin(a)*r*0.9;
    }
  }

  const colorForStatus = (st) => st==="online" ? "#00ff88" : (st==="maint" ? "#ffcc33" : "#ff4d4d");

  function drawMap(){
    if(!canvas) return;
    const ctx = canvas.getContext("2d");
    const rect = canvas.getBoundingClientRect();
    const w = rect.width, h = rect.height;
    ctx.clearRect(0,0,w,h);

    ctx.save();
    ctx.globalAlpha = 0.10;
    ctx.strokeStyle = "#cfd8df";
    ctx.lineWidth = 1;
    const step = 26;
    for(let x=0;x<w;x+=step){ ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,h); ctx.stroke(); }
    for(let y=0;y<h;y+=step){ ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(w,y); ctx.stroke(); }
    ctx.restore();

    layoutNodes(w,h);

    const master = nodes[0];
    nodes.slice(1).forEach(n=>{
      ctx.save();
      ctx.lineWidth = 2;
      ctx.globalAlpha = 0.55;
      ctx.strokeStyle = colorForStatus(n.status);
      ctx.beginPath();
      ctx.moveTo(master.x, master.y);
      ctx.lineTo(n.x, n.y);
      ctx.stroke();

      const t = (Date.now()/1000) % 1;
      const px = master.x + (n.x-master.x)*t;
      const py = master.y + (n.y-master.y)*t;
      ctx.globalAlpha = 0.9;
      ctx.fillStyle = colorForStatus(n.status);
      ctx.beginPath();
      ctx.arc(px, py, 3.2, 0, Math.PI*2);
      ctx.fill();
      ctx.restore();
    });

    nodes.forEach(n=>{
      const c = colorForStatus(n.status);
      ctx.save();
      ctx.shadowColor = c;
      ctx.shadowBlur = 14;
      ctx.fillStyle = c;
      ctx.globalAlpha = 0.85;
      ctx.beginPath();
      ctx.arc(n.x, n.y, n.id==="MASTER" ? 10 : 7, 0, Math.PI*2);
      ctx.fill();

      ctx.shadowBlur = 0;
      ctx.globalAlpha = 0.9;
      ctx.strokeStyle = c;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(n.x, n.y, n.id==="MASTER" ? 18 : 14, 0, Math.PI*2);
      ctx.stroke();

      ctx.globalAlpha = 0.9;
      ctx.fillStyle = "#cfd8df";
      ctx.font = "12px JetBrains Mono, monospace";
      ctx.fillText(n.id, n.x + 14, n.y - 10);
      ctx.globalAlpha = 0.65;
      ctx.fillStyle = "#8ea0ad";
      ctx.fillText(`${n.role} / ${n.lat}ms`, n.x + 14, n.y + 6);
      ctx.restore();
    });

    requestAnimationFrame(drawMap);
  }

  function hitTest(x,y){
    for(const n of nodes){
      const r = (n.id==="MASTER" ? 18 : 14);
      const dx = x - n.x, dy = y - n.y;
      if(dx*dx + dy*dy <= r*r) return n;
    }
    return null;
  }

  if(canvas){
    canvas.addEventListener("mousemove", (e) => {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const n = hitTest(x,y);
      if(!tip) return;
      if(n){
        tip.style.display = "block";
        tip.style.left = x + "px";
        tip.style.top = y + "px";
        const st = n.status === "online" ? "ONLINE" : (n.status === "maint" ? "MAINT" : "OFFLINE");
        tip.innerHTML = `<b>${n.id}</b> <span class="muted">(${n.role})</span><br>
          IP: <span class="muted">${n.ip}</span><br>
          STATUS: <b>${st}</b><br>
          LATENCY: <b>${n.lat}ms</b>`;
      } else tip.style.display = "none";
    });
    canvas.addEventListener("mouseleave", () => { if(tip) tip.style.display = "none"; });
    canvas.addEventListener("click", (e) => {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const n = hitTest(x,y);
      if(!n || n.id==="MASTER") return;
      n.status = (n.status === "online") ? "maint" : (n.status === "maint" ? "offline" : "online");
      logEvent(n.status === "offline" ? "ERR" : "WARN", `${n.id} status -> ${n.status.toUpperCase()}`);
      if(n.status === "offline"){
        setAlert(true, `${n.id} OFFLINE`);
        setTimeout(()=> setAlert(false), 8000);
      }
      beep();
    });
    drawMap();
  }

  // Hotkeys: Dev info and Admin mode
  window.addEventListener("keydown", (e)=>{
    if(e.ctrlKey && e.altKey && e.key.toLowerCase()==="s"){
      const info = $("#devInfo");
      if(info){
        info.style.display = (info.style.display === "none" ? "" : "none");
        beep();
        logEvent("OK", "DEV INFO toggled");
      }
    }
    if(e.ctrlKey && e.altKey && e.key.toLowerCase()==="a"){
      setAdmin(!prefs.admin);
    }
  });

})();
