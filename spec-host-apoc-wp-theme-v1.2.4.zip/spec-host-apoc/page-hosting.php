<?php get_header(); ?>

<section class="page">
  <?php echo do_shortcode('[spec_module_head module="hosting" fallback_title="HOSTING CORE" fallback_desc="Классический хостинг под сайты и приложения. SSL, proxy, быстрый старт." btn1_text="START HOSTING" btn1_url="#" btn2_text="ADMIN: CREATE SITE" btn2_url="#"]'); ?>

  <?php echo do_shortcode('[spec_module_blocks module="hosting" keys="features,security,deploy,admin" layout="grid2"]'); ?>
</section>

<section class="page">
  <h2 style="margin:0 0 14px 0">Тарифы Hosting</h2>
  <?php echo do_shortcode('[spec_tariffs type="hosting" limit="12"]'); ?>
</section>

<?php get_footer(); ?>
