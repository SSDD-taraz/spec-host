
<div id="logPanel" class="log-panel">
  <div class="head">
    <span>SYSTEM LOG</span>
    <div class="settings">
      <label class="toggle"><input id="toggleSound" type="checkbox"> SOUND</label>
      <label class="toggle"><input id="toggleBoot" type="checkbox"> BOOT</label>
      <label class="toggle"><input id="toggleLogs" type="checkbox" checked> LOGS</label>
      <span class="admin-badge">ADMIN MODE</span>
    </div>
  </div>
  <div id="logBody" class="body"></div>
</div>

<div id="devInfo" class="log-panel" style="display:none;">
  <div class="head"><span>DEV INFO</span><span style="color:var(--muted);font-size:12px;">CTRL+ALT+S</span></div>
  <div class="body">
    <div class="line">ADMIN HOTKEY: <b class="ok">CTRL+ALT+A</b></div>
    <div class="line">TIP: click EDGE nodes on map to demo statuses</div>
  </div>
</div>

<div class="footer">
  <span>SPEC-HOST // apocalypse UI v3.1 (WP)</span>
  <span>Hint: CTRL+ALT+A → Admin Mode</span>
</div>

</div><!-- /.shell -->

<?php wp_footer(); ?>
</body>
</html>
