<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;800&display=swap" rel="stylesheet">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="boot" class="boot">
  <div class="frame">
    <h2>SPEC-HOST :: SYSTEM BOOT</h2>
    <div id="bootLog" class="log"></div>
    <div class="actions">
      <button id="bootEnter" class="enter">PRESS ENTER TO ACCESS CONTROL ROOM</button>
    </div>
  </div>
</div>

<div class="shell">

  <section class="topbar">
    <div class="logo-bg"></div>
    <div class="brand">
      <h1>SPEC-HOST // SURVIVAL-GRADE HOSTING</h1>
      <div class="right-indicators">
        <div class="pill"><span class="dot"></span> POWER: STABLE</div>
        <div class="pill"><span class="dot yellow"></span> CORE TEMP: OK</div>
        <div class="pill"><span class="dot"></span> MODE: OPERATIONAL</div>
      </div>
    </div>

    <nav class="nav">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="<?php echo sh_is_active('home') ? 'active' : ''; ?>">Main</a>
      <a href="<?php echo esc_url(sh_page_url('vds')); ?>" class="<?php echo sh_is_active('vds') ? 'active' : ''; ?>">VDS</a>
      <a href="<?php echo esc_url(sh_page_url('hosting')); ?>" class="<?php echo sh_is_active('hosting') ? 'active' : ''; ?>">Hosting</a>
      <a href="<?php echo esc_url(sh_page_url('static-ip')); ?>" class="<?php echo sh_is_active('static-ip') ? 'active' : ''; ?>">Static IP</a>
      <a href="<?php echo esc_url(sh_page_url('vpn-nodes')); ?>" class="<?php echo sh_is_active('vpn-nodes') ? 'active' : ''; ?>">VPN / Nodes</a>
    </nav>

    <div class="statsbar">
      <div class="stat">UPTIME <span class="v" id="uptime">99.99%</span></div>
      <div class="stat">NODES ONLINE <span class="v" id="nodes">128 ACTIVE</span></div>
      <div class="stat">LATENCY <span class="v" id="latency">12 MS</span></div>
    </div>
  </section>

  <div id="alertBanner" class="alert-banner"></div>
