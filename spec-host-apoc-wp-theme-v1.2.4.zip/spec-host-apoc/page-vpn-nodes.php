<?php get_header(); ?>

<section class="page">
  <?php echo do_shortcode('[spec_module_head module="vpn" fallback_title="VPN / NODES" fallback_desc="WireGuard overlay сеть для нод. Управление edge VDS, пробросы, объединение сетей." btn1_text="CONNECT NODE" btn1_url="#" btn2_text="ADMIN: ADD NODE" btn2_url="#"]'); ?>

  <?php echo do_shortcode('[spec_module_blocks module="vpn" keys="features,security,deploy,admin" layout="grid2"]'); ?>
</section>

<section class="page">
  <h2 style="margin:0 0 14px 0">Тарифы VPN / Nodes</h2>
  <?php echo do_shortcode('[spec_tariffs type="vpn-nodes" limit="12"]'); ?>
</section>

<?php get_footer(); ?>
