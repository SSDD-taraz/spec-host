<?php
// Spec-Host Apocalypse theme

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    register_nav_menus([
        'primary' => 'Primary Navigation',
    ]);
});

add_action('wp_enqueue_scripts', function () {
    $ver = '1.0.0';
    // Main layout CSS
    wp_enqueue_style('spec-host-apoc', get_template_directory_uri() . '/assets/css/style.css', [], $ver);
    // App JS
    wp_enqueue_script('spec-host-apoc', get_template_directory_uri() . '/assets/js/app.js', [], $ver, true);
});

// Helper: get URL by page slug (fallback to #)
function sh_page_url(string $slug, string $fallback = '#'): string {
    $page = get_page_by_path($slug);
    return $page ? get_permalink($page) : $fallback;
}

function sh_is_active(string $slug): bool {
    if (is_front_page() && $slug === 'home') return true;
    $page = get_page_by_path($slug);
    return $page && is_page($page);
}


/**
 * Spec-Host: Editable tariffs + site options (ACF-ready)
 * Требуется плагин Advanced Custom Fields (ACF).
 */

// CPT: Tariffs + taxonomy
add_action('init', function () {
    register_post_type('spec_tariff', [
        'labels' => [
            'name' => 'Тарифы',
            'singular_name' => 'Тариф',
            'add_new' => 'Добавить тариф',
            'add_new_item' => 'Добавить тариф',
            'edit_item' => 'Редактировать тариф',
            'new_item' => 'Новый тариф',
            'view_item' => 'Просмотр тарифа',
            'search_items' => 'Найти тариф',
            'not_found' => 'Тарифы не найдены',
            'menu_name' => 'Тарифы',
        ],
        'public' => true,
        'show_in_rest' => true,
        'menu_icon' => 'dashicons-list-view',
        'supports' => ['title', 'editor', 'page-attributes'],
        'has_archive' => false,
        'rewrite' => ['slug' => 'tariffs'],
    ]);

    register_taxonomy('spec_tariff_type', ['spec_tariff'], [
        'labels' => [
            'name' => 'Категории тарифов',
            'singular_name' => 'Категория тарифов',
            'menu_name' => 'Категории',
        ],
        'public' => true,
        'show_in_rest' => true,
        'hierarchical' => true,
        'rewrite' => ['slug' => 'tariff-type'],
    ]);
});

// Shortcode: [spec_tariffs type="vds" limit="12"]
add_shortcode('spec_tariffs', function ($atts) {
    $atts = shortcode_atts([
        'type'  => 'vds',   // vds|hosting|static-ip|vpn-nodes
        'limit' => 12,
    ], $atts);

    $q = new WP_Query([
        'post_type'      => 'spec_tariff',
        'posts_per_page' => (int)$atts['limit'],
        'orderby'        => 'menu_order',
        'order'          => 'ASC',
        'tax_query'      => [[
            'taxonomy' => 'spec_tariff_type',
            'field'    => 'slug',
            'terms'    => [$atts['type']],
        ]],
    ]);

    if (!$q->have_posts()) {
        return '<div class="muted">Тарифы скоро появятся.</div>';
    }

    ob_start();
    echo '<div class="spec-tariffs-grid">';
    while ($q->have_posts()) {
        $q->the_post();

        $price    = function_exists('get_field') ? (string)get_field('price') : '';
        $period   = function_exists('get_field') ? ((string)get_field('period') ?: 'мес') : 'мес';
        $currency = function_exists('get_field') ? ((string)get_field('currency') ?: '₸') : '₸';

        $cpu     = function_exists('get_field') ? (string)get_field('cpu') : '';
        $ram     = function_exists('get_field') ? (string)get_field('ram') : '';
        $disk    = function_exists('get_field') ? (string)get_field('disk') : '';
        $traffic = function_exists('get_field') ? (string)get_field('traffic') : '';
        $ipv4    = function_exists('get_field') ? (string)get_field('ipv4') : '';
        $ipv6    = function_exists('get_field') ? (string)get_field('ipv6') : '';

        $badge     = function_exists('get_field') ? (string)get_field('badge') : '';
        $order_url = function_exists('get_field') ? (string)get_field('order_url') : '';

        $features = [];
        if (function_exists('have_rows') && have_rows('features')) {
            while (have_rows('features')) { the_row();
                $t = (string)get_sub_field('text');
                if ($t !== '') $features[] = $t;
            }
        }

        echo '<div class="card spec-tariff-card">';
        echo '<div class="row"><h3 style="margin:0">'.esc_html(get_the_title()).'</h3>';
        if ($badge) echo '<span class="tag" style="margin-left:auto">'.esc_html($badge).'</span>';
        echo '</div>';

        if ($price !== '') {
            echo '<div class="spec-price">'.esc_html($price).' '.esc_html($currency).' <span class="muted">/ '.esc_html($period).'</span></div>';
        }

        echo '<ul class="spec-meta">';
        if ($cpu)     echo '<li><span class="muted">CPU</span> '.esc_html($cpu).'</li>';
        if ($ram)     echo '<li><span class="muted">RAM</span> '.esc_html($ram).'</li>';
        if ($disk)    echo '<li><span class="muted">DISK</span> '.esc_html($disk).'</li>';
        if ($traffic) echo '<li><span class="muted">TRAFFIC</span> '.esc_html($traffic).'</li>';
        if ($ipv4 !== '') echo '<li><span class="muted">IPv4</span> '.esc_html($ipv4).'</li>';
        if ($ipv6 !== '') echo '<li><span class="muted">IPv6</span> '.esc_html($ipv6).'</li>';
        echo '</ul>';

        if ($features) {
            echo '<ul class="spec-features">';
            foreach ($features as $f) echo '<li>'.esc_html($f).'</li>';
            echo '</ul>';
        } else {
            // если редактор заполнен — покажем как описание
            $desc = trim(wp_strip_all_tags(get_the_content()));
            if ($desc !== '') echo '<div class="muted" style="margin-top:10px">'.esc_html($desc).'</div>';
        }

        if ($order_url) {
            echo '<a class="btn" style="margin-top:14px;display:inline-block" href="'.esc_url($order_url).'">Заказать</a>';
        }

        echo '</div>';
    }
    wp_reset_postdata();
    echo '</div>';

    return ob_get_clean();
});

// ACF: Options page + local field groups (автоматически, без ручного создания)
add_action('acf/init', function () {
    if (!function_exists('acf_add_local_field_group')) return;

    if (function_exists('acf_add_options_page')) {
        acf_add_options_page([
            'page_title' => 'Spec-Host — Настройки',
            'menu_title' => 'Spec-Host',
            'menu_slug'  => 'spec-host-options',
            'capability' => 'manage_options',
            'redirect'   => false,
            'position'   => 58,
            'icon_url'   => 'dashicons-admin-generic',
        ]);
    }

    // Поля тарифа
    acf_add_local_field_group([
        'key' => 'group_spec_tariff',
        'title' => 'Тариф: параметры',
        'fields' => [
            ['key'=>'field_spec_price','label'=>'Цена','name'=>'price','type'=>'text'],
            ['key'=>'field_spec_currency','label'=>'Валюта','name'=>'currency','type'=>'text','default_value'=>'₸','wrapper'=>['width'=>'30']],
            ['key'=>'field_spec_period','label'=>'Период','name'=>'period','type'=>'text','default_value'=>'мес','wrapper'=>['width'=>'30']],
            ['key'=>'field_spec_badge','label'=>'Бейдж (ХИТ/NEW)','name'=>'badge','type'=>'text','wrapper'=>['width'=>'40']],

            ['key'=>'field_spec_cpu','label'=>'CPU','name'=>'cpu','type'=>'text','wrapper'=>['width'=>'33']],
            ['key'=>'field_spec_ram','label'=>'RAM','name'=>'ram','type'=>'text','wrapper'=>['width'=>'33']],
            ['key'=>'field_spec_disk','label'=>'Disk','name'=>'disk','type'=>'text','wrapper'=>['width'=>'34']],

            ['key'=>'field_spec_traffic','label'=>'Traffic','name'=>'traffic','type'=>'text','wrapper'=>['width'=>'50']],
            ['key'=>'field_spec_ipv4','label'=>'IPv4','name'=>'ipv4','type'=>'text','wrapper'=>['width'=>'25']],
            ['key'=>'field_spec_ipv6','label'=>'IPv6','name'=>'ipv6','type'=>'text','wrapper'=>['width'=>'25']],

            ['key'=>'field_spec_order_url','label'=>'Ссылка "Заказать"','name'=>'order_url','type'=>'url'],

            [
                'key'=>'field_spec_features',
                'label'=>'Фичи (список)',
                'name'=>'features',
                'type'=>'repeater',
                'layout'=>'table',
                'button_label'=>'Добавить пункт',
                'sub_fields'=>[
                    ['key'=>'field_spec_feature_text','label'=>'Текст','name'=>'text','type'=>'text'],
                ],
            ],
        ],
        'location' => [[[
            'param' => 'post_type',
            'operator' => '==',
            'value' => 'spec_tariff',
        ]]],
    ]);

    // Глобальные настройки
    acf_add_local_field_group([
        'key' => 'group_spec_site',
        'title' => 'Spec-Host: Глобальные настройки',
        'fields' => [
            ['key'=>'field_spec_tg','label'=>'Telegram URL','name'=>'telegram_url','type'=>'url'],
            ['key'=>'field_spec_wa','label'=>'WhatsApp URL','name'=>'whatsapp_url','type'=>'url'],
            ['key'=>'field_spec_email','label'=>'Email','name'=>'contact_email','type'=>'text'],
            ['key'=>'field_spec_phone','label'=>'Телефон','name'=>'contact_phone','type'=>'text'],
        ],
        'location' => [[[
            'param' => 'options_page',
            'operator' => '==',
            'value' => 'spec-host-options',
        ]]],
    ]);
});

