<?php get_header(); ?>
<section class="page">
  <div class="page-head">
    <div>
      <h2><?php echo is_home() ? 'News / Logs' : 'Content'; ?></h2>
      <p><?php bloginfo('description'); ?></p>
    </div>
  </div>
  <div class="grid2">
    <div class="card" style="grid-column:1/-1;">
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <article style="margin-bottom:18px;">
          <h3 style="margin:0 0 6px;"><a href="<?php the_permalink(); ?>" style="color:inherit;text-decoration:none;"><?php the_title(); ?></a></h3>
          <div class="mono" style="opacity:.9;">
            <?php the_excerpt(); ?>
          </div>
        </article>
      <?php endwhile; else: ?>
        <div class="mono">No entries.</div>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php get_footer(); ?>
