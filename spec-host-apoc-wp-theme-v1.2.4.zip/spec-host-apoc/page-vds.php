<?php get_header(); ?>

<section class="page">
  <?php echo do_shortcode('[spec_module_head module="vds" fallback_title="VDS MODULE" fallback_desc="Виртуальные серверы под сайты, game-сервера, VPN и панели. Быстрый запуск." btn1_text="ORDER VDS" btn1_url="#" btn2_text="ADMIN TOOLS" btn2_url="#"]'); ?>

  <?php echo do_shortcode('[spec_module_blocks module="vds" keys="plans,included,deploy,admin" layout="grid2"]'); ?>
</section>

<section class="page">
  <h2 style="margin:0 0 14px 0">Тарифы VDS</h2>
  <?php echo do_shortcode('[spec_vds_plans]'); ?>
</section>

<?php get_footer(); ?>
