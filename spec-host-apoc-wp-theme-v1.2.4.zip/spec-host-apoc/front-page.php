<?php get_header(); ?>

<section class="hero">
  <div class="modules">
    <div class="modules-grid">

      <article class="module">
        <div class="title">
          <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/icon-server.png'); ?>" alt="">
          <h2>VDS MODULE</h2>
        </div>
        <ul>
          <li>CPU: Xeon / Ryzen</li>
          <li>RAM: from 2 GB</li>
          <li>NVMe / SSD</li>
          <li>IPv4 included</li>
        </ul>
        <div class="kv">
          <div class="k">SERVERS: <b>ONLINE</b></div>
          <div class="k">LOAD: <b>NORMAL</b></div>
        </div>
        <a class="btn" href="<?php echo esc_url(sh_page_url('vds')); ?>">DEPLOY VDS</a>
      </article>

      <article class="module">
        <div class="title">
          <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/icon-shield.png'); ?>" alt="">
          <h2>HOSTING CORE</h2>
        </div>
        <ul>
          <li>Web / App Hosting</li>
          <li>Fast IO</li>
          <li>DDoS Shield</li>
          <li>Auto SSL / Reverse Proxy</li>
        </ul>
        <div class="kv">
          <div class="k">CORE: <b>STABLE</b></div>
          <div class="k">TRAFFIC: <b>NORMAL</b></div>
        </div>
        <a class="btn" href="<?php echo esc_url(sh_page_url('hosting')); ?>">START HOSTING</a>
      </article>

      <article class="module">
        <div class="title">
          <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/icon-shield.png'); ?>" alt="">
          <h2>STATIC IP ACCESS</h2>
        </div>
        <ul>
          <li>IPv4 / IPv6</li>
          <li>Home Lab / Cameras</li>
          <li>Server / VPN / Game</li>
          <li>Fast activation</li>
        </ul>
        <div class="kv">
          <div class="k">IP POOL: <b>AVAILABLE</b></div>
          <div class="k">ROUTE: <b>READY</b></div>
        </div>
        <a class="btn" href="<?php echo esc_url(sh_page_url('static-ip')); ?>">GET IP</a>
      </article>

    </div>
  </div>

  <aside class="side">
    <div class="panel-title">
      <span>VDS STATUS</span>
      <span class="tag">LIVE FEED</span>
    </div>

    <div class="servers">
      <div class="server">
        <div class="row"><span>NODE-01 (KZ)</span><span class="badge on">ONLINE</span></div>
        <div class="row" style="margin-top:6px;color:var(--muted)"><span>LATENCY</span><span>12 ms</span></div>
      </div>
      <div class="server">
        <div class="row"><span>NODE-02 (EU)</span><span class="badge on">ONLINE</span></div>
        <div class="row" style="margin-top:6px;color:var(--muted)"><span>LATENCY</span><span>18 ms</span></div>
      </div>
      <div class="server">
        <div class="row"><span>NODE-03 (EDGE)</span><span class="badge maint">MAINT</span></div>
        <div class="row" style="margin-top:6px;color:var(--muted)"><span>ETA</span><span>00:12</span></div>
      </div>
      <div class="server">
        <div class="row"><span>NODE-04 (CORE)</span><span class="badge on">ONLINE</span></div>
        <div class="row" style="margin-top:6px;color:var(--muted)"><span>LATENCY</span><span>11 ms</span></div>
      </div>
    </div>

    <div style="margin-top:14px; display:grid; gap:10px;">
      <a class="qbtn admin-only" href="#" style="justify-content:center;">ADMIN: FIREWALL</a>
      <a class="qbtn admin-only" href="#" style="justify-content:center;">ADMIN: PORT MAP</a>
      <a class="qbtn admin-only" href="<?php echo esc_url(sh_page_url('vpn-nodes')); ?>" style="justify-content:center;">ADMIN: ADD NODE</a>
    </div>
  </aside>
</section>

<div class="hazard">
  <span>NETWORK STATUS:</span>
  <span class="green">ONLINE</span>
  <span>/</span>
  <span>DDOS SHIELD:</span>
  <span class="yellow">ACTIVE</span>
</div>

<?php get_footer(); ?>
