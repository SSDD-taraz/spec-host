<?php get_header(); ?>
<section class="page">
  <div class="page-head">
    <div>
      <h2><?php the_title(); ?></h2>
      <p><?php echo esc_html(get_bloginfo('description')); ?></p>
    </div>
  </div>
  <div class="grid2">
    <div class="card" style="grid-column:1/-1;">
      <?php while (have_posts()) : the_post(); the_content(); endwhile; ?>
    </div>
  </div>
</section>
<?php get_footer(); ?>
