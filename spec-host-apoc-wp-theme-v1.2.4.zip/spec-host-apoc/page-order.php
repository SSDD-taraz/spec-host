<?php
/*
Template Name: Order (Spec-Host)
*/
get_header(); ?>

<section class="page">
  <div class="page-head">
    <div>
      <h2>ORDER / ЗАЯВКА</h2>
      <p>Оставь заявку — мы быстро подключим услугу и выдадим доступы.</p>
    </div>
  </div>

  <?php echo do_shortcode('[spec_order_form title="Заявка"]'); ?>
</section>

<?php get_footer(); ?>
